import java.util.Scanner;
class CSVExtractor{
	public static void main(String args[])
	{
		Scanner Sc=new Scanner(System.in);
		String S;
		System.out.println("Enter String object that contains comma separate double values for example of '3.5,12.9,18.7,121.54' ");
		S=Sc.next();
		String arr[]=S.split(",");
		int n=arr.length;
		double d[]=new double[n];
		System.out.println("Your Result ;-");
		for(int i=0;i<arr.length;i++){
			d[i]=Double.parseDouble(arr[i]);
			System.out.println(d[i]);
		}
	}
}
import java.util.Scanner;
class DataReverser{
      public static void main(String[] args) {
      	Scanner Sc=new Scanner(System.in);
      	int l;
	    System.out.println("Enter Length of the Array");
        l=Sc.nextInt();
        int arr[]=new int[l];
        System.out.println("Enter Elements In Array");
        for(int i=0;i<l;i++){
        	arr[i]=Sc.nextInt();
        }
        for(int i=0;i<l/2;i++)
        {
        	int temp=arr[i];
        	arr[i]=arr[l-i-1];
        	arr[l-i-1]=temp;
        }
        System.out.println("Your Result is :-");
        for(int i=0;i<l;i++){
        	System.out.println(arr[i]);
        }
	}
}
import java.util.Scanner;
class Primenumberchecker{
	public static void main(String args[]){
		System.out.println("Enter A number ");
		Scanner Sc=new Scanner(System.in);
		int n,flag=0;
		n=Sc.nextInt();
		if(n<=1){
			flag=1;
		}
		for(int i=2;i<=n/2;i++){
            if(n%i==0){
            	flag=1;
            	break;
            }
		}
		if(flag==0){
           System.out.println("Number is prime ");
		}
		else{
			System.out.println("Number is not prime");
		}

	}
}
import java.util.*;
class FrequencyCalculator{
	public static void main(String args[]){
     Random rand=new Random();
     int number[]=new int[100];
     int counter[]=new int[11];
     for(int i=0;i<100;i++){
      number[i]=rand.nextInt(11);
     }
     for(int i=0;i<number.length;i++){
     	counter[number[i]]++;
     }

     
     for(int i=0;i<counter.length;i++){
     	System.out.println("Number of "+i+" are "+counter[i]);
     }
	}
}